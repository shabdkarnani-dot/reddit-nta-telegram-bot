import Database from 'better-sqlite3';
import path from 'path';

const dbPath = process.env.DB_PATH || path.resolve(__dirname, '..', 'data', 'store.db');
const db = new Database(dbPath);

// Initialize tables
db.prepare(`CREATE TABLE IF NOT EXISTS reddit_last (
  subreddit TEXT PRIMARY KEY,
  last_id TEXT
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS nta_last (
  id INTEGER PRIMARY KEY CHECK (id = 0),
  last_link TEXT
)`).run();

export function getRedditLast(subreddit: string): string | null {
  const row = db.prepare('SELECT last_id FROM reddit_last WHERE subreddit = ?').get(subreddit);
  return row ? row.last_id : null;
}

export function setRedditLast(subreddit: string, lastId: string) {
  db.prepare('INSERT INTO reddit_last (subreddit, last_id) VALUES (?, ?) ON CONFLICT(subreddit) DO UPDATE SET last_id=excluded.last_id').run(subreddit, lastId);
}

export function getNtaLast(): string | null {
  const row = db.prepare('SELECT last_link FROM nta_last WHERE id = 0').get();
  return row ? row.last_link : null;
}

export function setNtaLast(link: string) {
  db.prepare('INSERT INTO nta_last (id, last_link) VALUES (0, ?) ON CONFLICT(id) DO UPDATE SET last_link=excluded.last_link').run(link);
}

export default db;
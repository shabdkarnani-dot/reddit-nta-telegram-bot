import 'dotenv/config';
import { Telegraf } from 'telegraf';
import { CronJob } from 'cron';
import { fetchNewPosts, RedditPost } from './reddit';
import { fetchNta, NtaItem } from './nta';
import * as db from './db';
import { escapeMarkdownV2, trim } from './utils';

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const CHAT_ID = process.env.TELEGRAM_CHAT_ID;
const POLL_MINUTES = parseInt(process.env.POLL_MINUTES || '5', 10);
const SUBREDDITS = (process.env.SUBREDDITS || '').split(',').map(s => s.trim()).filter(Boolean);
const NTA_RSS_URL = process.env.NTA_RSS_URL;

if (!BOT_TOKEN) {
  console.error('Missing TELEGRAM_BOT_TOKEN in .env');
  process.exit(1);
}
if (!CHAT_ID) {
  console.error('Missing TELEGRAM_CHAT_ID in .env');
  process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN);

async function sendMessage(text: string) {
  try {
    await bot.telegram.sendMessage(CHAT_ID as any, text, { parse_mode: 'MarkdownV2', disable_web_page_preview: false });
  } catch (err) {
    console.error('sendMessage error', err);
  }
}

async function checkRedditOnce() {
  if (SUBREDDITS.length === 0) return;
  for (const sub of SUBREDDITS) {
    try {
      const posts = await fetchNewPosts(sub, 10);
      if (!posts.length) continue;
      const lastSeen = db.getRedditLast(sub);
      for (const p of posts.slice().reverse() as RedditPost[]) {
        if (lastSeen && lastSeen === p.id) break;
        const text = `🔴 *New post in* _r/${escapeMarkdownV2(sub)}_\n\n*${escapeMarkdownV2(p.title)}*\n_by ${escapeMarkdownV2(p.author)}_\n\n[Open post](${escapeMarkdownV2(p.permalink)})`;
        await sendMessage(text);
      }
      db.setRedditLast(sub, posts[0].id);
    } catch (err) {
      console.error('Error checking subreddit', sub, err);
    }
  }
}

async function checkNtaOnce() {
  if (!NTA_RSS_URL) return;
  try {
    const items = await fetchNta(NTA_RSS_URL, 5);
    if (!items.length) return;
    const last = db.getNtaLast();
    for (const it of items.slice().reverse() as NtaItem[]) {
      if (last && last === it.link) break;
      const text = `📢 *NTA Announcement*\n\n*${escapeMarkdownV2(it.title)}*\n\n${escapeMarkdownV2(trim(it.contentSnippet || it.content || '', 500))}\n\n[Read more](${escapeMarkdownV2(it.link)})`;
      await sendMessage(text);
    }
    db.setNtaLast(items[0].link);
  } catch (err) {
    console.error('Error checking NTA RSS', err);
  }
}

async function runOnce() {
  console.log(new Date().toISOString(), 'Running checks...');
  await checkRedditOnce();
  await checkNtaOnce();
}

(async function main() {
  await runOnce();
  const pattern = `0 */${POLL_MINUTES} * * * *`;
  const job = new CronJob(pattern, async () => {
    await runOnce();
  }, null, true, 'UTC');
  job.start();

  bot.start((ctx) => ctx.reply('Hello! I am the notifier bot.'));
  bot.command('status', async (ctx) => {
    await ctx.reply('Bot is running. Monitored subreddits: ' + SUBREDDITS.join(', '));
  });
  bot.launch();

  console.log('Bot started. Polling every', POLL_MINUTES, 'minutes.');
})();
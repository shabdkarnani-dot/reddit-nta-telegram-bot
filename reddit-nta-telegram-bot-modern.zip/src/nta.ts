import Parser from 'rss-parser';
const parser = new Parser();

export type NtaItem = {
  title: string;
  link: string;
  content?: string;
  contentSnippet?: string;
};

export async function fetchNta(feedUrl: string, limit = 5): Promise<NtaItem[]> {
  const feed = await parser.parseURL(feedUrl);
  return (feed.items || []).slice(0, limit).map((it: any) => ({
    title: it.title || '(no title)',
    link: it.link,
    content: it.content,
    contentSnippet: it.contentSnippet
  }));
}
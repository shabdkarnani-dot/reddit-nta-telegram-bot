import fetch from 'node-fetch';

const USER_AGENT = process.env.USER_AGENT || 'RedditNtaTelegramBot/1.0';

export type RedditPost = {
  id: string;
  title: string;
  url: string;
  permalink: string;
  author: string;
  created_utc: number;
};

export async function fetchNewPosts(subreddit: string, limit = 5): Promise<RedditPost[]> {
  const url = `https://www.reddit.com/r/${encodeURIComponent(subreddit)}/new.json?limit=${limit}`;
  const res = await fetch(url, { headers: { 'User-Agent': USER_AGENT }, timeout: 15000 } as any);
  if (!res.ok) throw new Error(`Reddit fetch failed ${res.status} ${res.statusText}`);
  const json = await res.json();
  if (!json.data || !Array.isArray(json.data.children)) return [];
  return json.data.children.map((c: any) => {
    const d = c.data;
    return {
      id: d.name || d.id,
      title: d.title,
      url: d.url && d.url.startsWith('/') ? `https://reddit.com${d.url}` : d.url,
      permalink: `https://reddit.com${d.permalink}`,
      author: d.author,
      created_utc: d.created_utc
    } as RedditPost;
  });
}
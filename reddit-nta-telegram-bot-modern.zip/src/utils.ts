export function escapeMarkdownV2(text: string): string {
  if (!text) return '';
  return text.replace(/([_\*\[\]()~`>#+\-=|{}.!\\])/g, '\\$1');
}

export function trim(s: string | undefined, n = 400) {
  if (!s) return '';
  return s.length > n ? s.slice(0, n - 3) + '...' : s;
}